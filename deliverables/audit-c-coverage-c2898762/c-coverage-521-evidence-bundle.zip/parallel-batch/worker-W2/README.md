# Worker worker-W2 Audit Deliverable

- **Assigned Count**: 60 APIs
- **Trials Run**: 180
- **Actual Calls**: 44
- **Attribute Access / Weak**: 10
- **Smoke Only**: 4
- **Environment Blocked**: 0
- **Verified APIs**: 42
- **Differ APIs**: 2
- **Contract Pending APIs**: 16
- **GWpy Value Parity**: 15
- **GWpy Exception Parity**: 12
- **GWpy Differs**: 0
- **Incomparable / Extension**: 31
- **Execution Duration**: 1.48s

## Deliverable Files
- `assigned-identifiers.jsonl`: Original input manifest (60 lines)
- `runtime-trials.jsonl`: Machine-readable trial evidence (180 lines)
- `api-dispositions.jsonl`: Final status and dispositions per API (60 lines)
- `summary.json`: Aggregated metrics
- `reproduce.py`: Standalone execution script
- `README.md`: This report
