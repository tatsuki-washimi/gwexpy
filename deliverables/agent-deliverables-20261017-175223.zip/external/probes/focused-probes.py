from __future__ import annotations
import sys
sys.path.insert(0, "/home/washimi/work/gwexpy")
import importlib.util
import json
import logging
import tempfile
import warnings
from pathlib import Path

import numpy as np
from astropy import units as u

out = {}

def capture(name, fn):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        try:
            result = fn()
            if isinstance(result, tuple):
                value = repr(result)
            else:
                value = result
            out[name] = {
                'status': 'returned',
                'result': value,
                'warnings': [
                    {
                        'category': w.category.__name__,
                        'message': str(w.message),
                        'filename': w.filename,
                        'lineno': w.lineno,
                    }
                    for w in caught
                ],
            }
        except Exception as exc:
            out[name] = {
                'status': 'raised',
                'type': type(exc).__name__,
                'message': str(exc),
                'cause_type': type(exc.__cause__).__name__ if exc.__cause__ else None,
                'context_type': type(exc.__context__).__name__ if exc.__context__ else None,
                'warnings': [
                    {
                        'category': w.category.__name__,
                        'message': str(w.message),
                        'filename': w.filename,
                        'lineno': w.lineno,
                    }
                    for w in caught
                ],
            }

try:
    from gwexpy.analysis.threshold import PercentileThreshold
    from gwexpy.frequencyseries import FrequencySeries, FrequencySeriesDict
    from gwexpy.histogram import HistogramDict
    from gwexpy.spectrogram import SpectrogramDict, SpectrogramList
    from gwexpy.timeseries import TimeSeries, TimeSeriesMatrix
    from gwexpy.timeseries.preprocess import standardize_matrix
    from gwexpy.timeseries.pipeline import StandardizeTransform
    from gwexpy.signal.preprocessing.whitening import whiten
except Exception as exc:
    out['imports'] = {'status': 'raised', 'type': type(exc).__name__, 'message': str(exc)}
    print(json.dumps(out, indent=2, ensure_ascii=False))
    raise SystemExit(0)

class _Rows:
    columns = ['psd']
    def __init__(self, rows): self._rows = rows
    def __len__(self): return len(self._rows)
    def row(self, i): return {'psd': self._rows[i]}

inj = FrequencySeries([10.0, 10.0, 10.0], f0=10*u.Hz, df=1*u.Hz, unit=u.m**2/u.Hz)
bkg_bad = FrequencySeries([1.0, 3.0, 7.0], f0=10*u.Hz, df=1*u.Hz, unit=u.s)
capture('threshold_incompatible_units', lambda: PercentileThreshold(percentile=50, factor=1).threshold(inj, None, bkg_table=_Rows([bkg_bad])))

matrix = TimeSeriesMatrix(np.array([[[1.0, 2.0, 4.0], [2.0, 4.0, 8.0]]]), dt=1*u.s, unit=u.m)
capture('standardize_matrix_unit', lambda: (standardize_matrix(matrix).units.tolist(), getattr(standardize_matrix(matrix), 'unit', None), standardize_matrix(matrix).value.tolist()))

complex_matrix = TimeSeriesMatrix(np.array([[[1+1j, -1+1j, -1-1j]]]), dt=1*u.s, unit=u.m)
def matrix_phase(which):
    result = getattr(complex_matrix, which)()
    return (which, repr(getattr(result, 'unit', None)), result.units.tolist(), np.asarray(result.value).tolist())
capture('matrix_radian', lambda: matrix_phase('radian'))
capture('matrix_degree', lambda: matrix_phase('degree'))

series = TimeSeries([1.0, 2.0, 4.0], dt=1*u.s, unit=u.m)
capture('standardize_transform_unit', lambda: (StandardizeTransform(method='zscore').fit_transform(series).unit, StandardizeTransform(method='zscore').fit_transform(series).value.tolist()))

capture('whiten_zca_warning', lambda: whiten(np.arange(60, dtype=float).reshape(20, 3), method='zca', n_components=2, return_model=False).shape)

with tempfile.TemporaryDirectory(prefix='gwexpy-error-audit-') as td:
    root = Path(td)
    broken_h5 = root / 'broken.h5'
    import h5py
    with h5py.File(broken_h5, 'w') as f:
        f.create_group('broken-entry')
    logger = logging.getLogger('gwexpy')
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    records = []
    class _Handler(logging.Handler):
        def emit(self, record): records.append(record.getMessage())
    handler = _Handler()
    logger.addHandler(handler)
    try:
        capture('spectrogram_dict_invalid_unmanifested_hdf5', lambda: len(SpectrogramDict().read(broken_h5, format='hdf5')))
        capture('spectrogram_list_invalid_unmanifested_hdf5', lambda: len(SpectrogramList().read(broken_h5, format='hdf5')))
        capture('frequencyseries_dict_invalid_unmanifested_hdf5', lambda: len(FrequencySeriesDict.read(broken_h5, format='hdf5')))
        capture('histogram_dict_invalid_unmanifested_hdf5', lambda: len(HistogramDict.read(broken_h5, format='hdf5')))
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)
    out['hdf5_debug_log_records'] = records
    out['netcdf4_module_available'] = importlib.util.find_spec('netCDF4') is not None
    bad_nc = root / 'not-a-netcdf.nc'
    bad_nc.write_text('not a NetCDF file', encoding='utf-8')
    capture('series_matrix_read_invalid_nc', lambda: TimeSeriesMatrix.read(bad_nc))
    missing_nc = root / 'absent-dir' / 'matrix.nc'
    missing_nc.parent.mkdir(exist_ok=True)
    missing_nc.parent.rmdir()
    capture('series_matrix_write_missing_parent_nc', lambda: matrix.write(missing_nc))

import gwexpy
out["gwexpy_file"] = gwexpy.__file__
print(json.dumps(out, indent=2, ensure_ascii=False, default=str))
