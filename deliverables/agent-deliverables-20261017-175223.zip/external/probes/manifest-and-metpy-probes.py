from __future__ import annotations
import sys
sys.path.insert(0, '/home/washimi/work/gwexpy')
import json
import tempfile
import warnings
from pathlib import Path
import numpy as np
import h5py
import xarray as xr
from gwexpy.fields import ScalarField
from gwexpy.interop.metpy_ import from_metpy_dataarray
from gwexpy.frequencyseries import FrequencySeriesDict
from gwexpy.histogram import HistogramDict
from gwexpy.spectrogram import SpectrogramDict, SpectrogramList
import gwexpy

out={'gwexpy_file':gwexpy.__file__}
def capture(name, fn):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        try:
            result=fn()
            out[name]={'status':'returned','result':repr(result),'warnings':[{'category':w.category.__name__,'message':str(w.message),'filename':w.filename,'lineno':w.lineno} for w in caught]}
        except Exception as exc:
            out[name]={'status':'raised','type':type(exc).__name__,'message':str(exc),'cause_type':type(exc.__cause__).__name__ if exc.__cause__ else None,'context_type':type(exc.__context__).__name__ if exc.__context__ else None,'warnings':[{'category':w.category.__name__,'message':str(w.message),'filename':w.filename,'lineno':w.lineno} for w in caught]}

bad_units=xr.DataArray(np.ones(3), dims=('time',), coords={'time':[0.,1.,2.]}, attrs={'units':'not_a_valid_unit'})
capture('metpy_invalid_unit_fallback',lambda: (from_metpy_dataarray(ScalarField,bad_units,dequantify=False).unit))
with tempfile.TemporaryDirectory(prefix='gwexpy-audit-manifest-') as td:
    path=Path(td)/'manifest.h5'
    with h5py.File(path,'w') as f:
        f.create_group('broken-entry')
        f.attrs['gwexpy_layout']='group-per-entry'
        f.attrs['gwexpy_order']='["broken-entry"]'
    capture('spectrogram_dict_manifest_bad_entry',lambda: len(SpectrogramDict().read(path,format='hdf5')))
    capture('spectrogram_list_manifest_bad_entry',lambda: len(SpectrogramList().read(path,format='hdf5')))
    capture('frequencyseries_dict_manifest_bad_entry',lambda: len(FrequencySeriesDict.read(path,format='hdf5')))
    capture('histogram_dict_manifest_bad_entry',lambda: len(HistogramDict.read(path,format='hdf5')))
print(json.dumps(out,indent=2,ensure_ascii=False))
