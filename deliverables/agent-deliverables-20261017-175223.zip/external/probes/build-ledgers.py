from __future__ import annotations
import collections
import json
import subprocess
from pathlib import Path

ROOT=Path('/home/washimi/work/gwexpy')
OUT=Path('/home/washimi/.local/state/gwexpy-error-audit/c2898762-20261017')
ARCH=Path('/home/washimi/.local/state/chat2plan/runs/20261017T064433Z-c8bd51')
CUR=Path('/home/washimi/.local/state/chat2plan/runs/20261017T075741Z-91daf9')
old=json.loads((ARCH/'execution/pass1-population.json').read_text())
new=json.loads((CUR/'execution/pass2-population-and-dispositions.json').read_text())
old_api_status=[json.loads(line) for line in (ARCH/'execution/pass2-api-status.jsonl').read_text().splitlines() if line]
rows=new['public_surface_2650']

# Existing per-entry behavior coverage from the earlier execution record.
api_status=collections.defaultdict(list)
dynamic_status=collections.defaultdict(list)
io_status={}
file_status={}
for row in old_api_status:
    kind=row['kind']
    if kind=='api': api_status[(row['member_id'],row['category'])].append(row['status'])
    elif kind=='dynamic': dynamic_status[(row['member_id'],row['category'])].append(row['status'])
    elif kind=='file': file_status[row['member_id']]=row['status']
    elif kind=='io':
        parts=row['member_id'].rsplit(':',1)
        if len(parts)==2:
            io_status[int(parts[1])]=row["status"]

old_io_occ=collections.defaultdict(int)
io_coverage={}
for global_index,item in enumerate(old["io"]):
    exact=(item["bucket"],item["format"],item["class"],item["function"])
    exact_idx=old_io_occ[exact]
    old_io_occ[exact]+=1
    io_coverage[(exact,exact_idx)]=io_status.get(global_index)

new_io_occ=collections.defaultdict(int)
coverage_rows=[]
missing_status=[]
for row in rows:
    surface=row['surface']
    status=None
    if surface=='api':
        key=(row['id'],row['category'])
        values=api_status.get(key,[])
        status=values[0] if values else None
    elif surface=='dynamic':
        key=(row['id'],row['category'])
        values=dynamic_status.get(key,[])
        status=values[0] if values else None
    elif surface=='io_registry':
        ident=row['id']
        bucket,fmt,tail=ident.split(':',2)
        cls,func=tail.split('->',1)
        exact=(bucket,fmt,cls,func)
        idx=new_io_occ[exact]
        new_io_occ[exact]+=1
        status=io_coverage.get((exact,idx))
    if status is None:
        missing_status.append(row['id'])
    evidence_scope={
        'pass2_static_pattern_recheck':'static_only_no_runtime_check',
        'pass2_not_evaluated':'not_evaluated',
        'pass1_evidence_reused':'prior_focused_behavior_evidence_reused',
        'pass2_executed':'focused_behavior_check_recorded',
    }.get(status,'missing_or_unmatched_status')
    coverage_rows.append({**row,'prior_behavior_status':status,'behavior_evidence_scope':evidence_scope,
                          'behavior_status_source':'20261017T064433Z-c8bd51/execution/pass2-api-status.jsonl'})

# File-level inventory reconciliation to the fixed Git tree.
tracked= subprocess.check_output(['git','ls-tree','-r','--name-only','c2898762ca68e20a1a241fffb3c3262b0a27290b','--','gwexpy'],cwd=ROOT,text=True).splitlines()
tracked_py=sorted(x for x in tracked if x.endswith('.py'))
old_files=sorted(x['path'] for x in old['files'])
repo_status=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
source_files={x['source_file'] for x in rows if isinstance(x.get('source_file'),str) and x['source_file'].startswith('gwexpy/')}
edge_files={x['path'] for x in old['edges']}

# Exact population comparisons with duplicate rows retained.
old_api=collections.Counter(x['member_id'] for x in old['apis'])
new_api=collections.Counter(x['id'] for x in rows if x['surface']=='api')
old_dynamic=collections.Counter(x['member_id'] for x in old['dynamic'])
new_dynamic=collections.Counter(x['id'] for x in rows if x['surface']=='dynamic')
old_io=collections.Counter((x['bucket'],x['format'],x['class'],x['function']) for x in old['io'])
new_io=collections.Counter((r['kind'],r['id'].split(':',2)[1],r['id'].split(':',2)[2].split('->',1)[0],r['id'].split('->',1)[1]) for r in rows if r['surface']=='io_registry')
file_rows=[r for r in old_api_status if r['kind']=='file']
behavior_by_surface={}
for kind in ('api','dynamic','io'):
    counts=collections.Counter(r['status'] for r in old_api_status if r['kind']==kind)
    behavior_by_surface[kind]=dict(sorted(counts.items()))
file_behavior=dict(sorted(collections.Counter(r['status'] for r in file_rows).items()))

summary={
  'baseline_pin':new['summary']['baseline_pin'],
  'observed_head':head,
  'head_matches_pin':head==new['summary']['baseline_pin'],
  'file_inventory':{
    'pass1_reported_files':len(old_files),'fixed_tree_python_files':len(tracked_py),
    'file_path_multiset_matches_fixed_tree':collections.Counter(old_files)==collections.Counter(tracked_py),
    'old_static_screened_count':old['summary']['files_static_screened'],
    'pass2_file_behavior_statuses':file_behavior,
    'file_to_api_linked_files_reported':old['summary']['files_linked_to_public_api'],
    'files_without_api_edge_reported':old['summary']['files_without_public_api_edge'],
  },
  'public_surface':{
    'pass1_api_rows':len(old['apis']),'pass2_surface_rows':len(rows),
    'rows_by_surface':dict(sorted(collections.Counter(r['surface'] for r in rows).items())),
    'rows_by_category':dict(sorted(collections.Counter(r['category'] for r in rows).items())),
    'exact_population_counters_match':old_api==new_api and old_dynamic==new_dynamic and old_io==new_io,
    'api_rows_match_with_duplicates':old_api==new_api,
    'dynamic_rows_match':old_dynamic==new_dynamic,
    'io_registry_rows_match':old_io==new_io,
    'pass2_static_dispositions':dict(sorted(collections.Counter(r['pass2_disposition'] for r in rows).items())),
    'behavior_statuses_from_execution_record':behavior_by_surface,
    'rows_without_behavior_status_crosswalk':len(missing_status),
    'rows_without_behavior_status_examples':missing_status[:20],
    'source_file_rows':sum(1 for r in rows if isinstance(r.get('source_file'),str) and r['source_file'].startswith('gwexpy/')),
    'unique_api_implementation_source_files':len(source_files),
    'previous_file_to_api_edge_files':len(edge_files),
    'class_or_host_files_in_edges_not_definition_source_rows':sorted(edge_files-source_files),
    'new_definition_source_files_not_in_old_edges':sorted(source_files-edge_files),
  },
  'static_inventory_summary':{
    'classes':old['summary']['public_classes'],
    'unverified_static_handlers':old['summary']['unverified_static_handlers'],
    'raises':new['summary']['raises_total'],'warnings':new['summary']['warns_total'],
    'warnings_with_stacklevel':new['summary']['warns_with_stacklevel'],
    'warnings_without_stacklevel':new['summary']['warns_missing_stacklevel'],
    'handler_disposition_rows':new['summary']['handlers_total'],
    'handler_dispositions':new['summary']['handlers_by_disposition'],
  },
  'evidence_limits':[
    'The archived pass1 population and pass2 status files document the scans; no per-command scanner transcript was located in the searched run archive.',
    'pass2_static_pattern_recheck is static-only; it does not establish runtime behavior or message quality for every API member.',
    'pass2_not_evaluated entries include inherited, dynamic, and external I/O wrapper surfaces without a GWexpy implementation body.',
    'The newer 2650-row static-disposition artifact has row-level AST observations but no per-row runtime transcript; its confirmed_issue label is not itself runtime confirmation.',
    'User-site-installed gwexpy was accidentally imported in an initial scratch run; those results were excluded. Retained probes prepend the fixed checkout path and report its __file__.',
  ],
  'repo_worktree_status':repo_status.splitlines(),
}

# Add matched behavior coverage without overwriting the static pass2 disposition.
with (OUT/'pass2-surface-coverage.jsonl').open('w') as f:
    for row in coverage_rows:
        f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')
with (OUT/'file-coverage.jsonl').open('w') as f:
    for row in old['files']:
        f.write(json.dumps({**row,'prior_behavior_status':file_status.get(row['path']),'behavior_evidence_scope':'static_only_no_runtime_check','source':'20261017T064433Z-c8bd51/execution/pass1-population.json + pass2-api-status.jsonl'},ensure_ascii=False,sort_keys=True)+'\n')
(OUT/'coverage-audit.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({
 'head_matches_pin':summary['head_matches_pin'],
 'file_list_matches':summary['file_inventory']['file_path_multiset_matches_fixed_tree'],
 'public_surface_exact_population_match':summary['public_surface']['exact_population_counters_match'],
 'rows_without_status_crosswalk':summary['public_surface']['rows_without_behavior_status_crosswalk'],
 'behavior_statuses':behavior_by_surface,
 'output_files':['coverage-audit.json','pass2-surface-coverage.jsonl','file-coverage.jsonl'],
},indent=2,ensure_ascii=False))
